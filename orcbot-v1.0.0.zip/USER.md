# User Profile

This file contains information about the user. The agent will learn and update this over time.

## Core Identity
- Name: Unknown
- Preferences: None known yet

## Learned Facts
(Empty)
