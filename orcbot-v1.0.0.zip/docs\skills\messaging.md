# Messaging Spec

Define messaging style, channel constraints, and delivery rules.

## Channels
- Telegram
- WhatsApp

## Rules
- When to send updates
- When to suppress duplicates
- Tone guidelines
