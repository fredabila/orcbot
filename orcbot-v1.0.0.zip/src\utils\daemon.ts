import fs from 'fs';
import path from 'path';
import os from 'os';
import { logger } from './logger';

export interface DaemonOptions {
    pidFile: string;
    logFile: string;
    dataDir: string;
}

export class DaemonManager {
    private pidFile: string;
    private logFile: string;
    private dataDir: string;

    constructor(options: DaemonOptions) {
        this.pidFile = options.pidFile;
        this.logFile = options.logFile;
        this.dataDir = options.dataDir;
    }

    /**
     * Get the PID file path
     */
    public getPidFile(): string {
        return this.pidFile;
    }

    /**
     * Get the log file path
     */
    public getLogFile(): string {
        return this.logFile;
    }

    /**
     * Get the data directory path
     */
    public getDataDir(): string {
        return this.dataDir;
    }

    /**
     * Check if a daemon is already running
     */
    public isRunning(): { running: boolean; pid?: number } {
        if (!fs.existsSync(this.pidFile)) {
            return { running: false };
        }

        try {
            const pidContent = fs.readFileSync(this.pidFile, 'utf8').trim();
            const pid = parseInt(pidContent, 10);

            if (isNaN(pid)) {
                // Invalid PID file, consider it not running
                return { running: false };
            }

            // Check if process is actually running
            try {
                process.kill(pid, 0); // Signal 0 checks if process exists without killing it
                return { running: true, pid };
            } catch (e) {
                // Process doesn't exist, stale PID file
                return { running: false };
            }
        } catch (error) {
            logger.error(`Error reading PID file: ${error}`);
            return { running: false };
        }
    }

    /**
     * Write the PID file
     */
    public writePidFile(pid: number): void {
        try {
            // Ensure data directory exists
            if (!fs.existsSync(this.dataDir)) {
                fs.mkdirSync(this.dataDir, { recursive: true });
            }

            fs.writeFileSync(this.pidFile, pid.toString(), 'utf8');
            logger.info(`PID file written: ${this.pidFile} (PID: ${pid})`);
        } catch (error) {
            logger.error(`Failed to write PID file: ${error}`);
            throw error;
        }
    }

    /**
     * Remove the PID file
     */
    public removePidFile(reason?: string): void {
        try {
            if (fs.existsSync(this.pidFile)) {
                fs.unlinkSync(this.pidFile);
                const suffix = reason ? ` (reason: ${reason})` : '';
                logger.info(`PID file removed: ${this.pidFile}${suffix}`);
            }
        } catch (error) {
            logger.error(`Failed to remove PID file: ${error}`);
        }
    }

    /**
     * Setup log file for daemon mode
     */
    public setupDaemonLogging(): void {
        const logDir = path.dirname(this.logFile);
        if (!fs.existsSync(logDir)) {
            fs.mkdirSync(logDir, { recursive: true });
        }

        // Redirect stdout and stderr to log file
        const logStream = fs.createWriteStream(this.logFile, { flags: 'a' });
        process.stdout.write = logStream.write.bind(logStream);
        process.stderr.write = logStream.write.bind(logStream);
    }

    /**
     * Daemonize the current process
     * Note: This implementation detaches the process without forking,
     * so the PID written is for the actual daemon process.
     */
    public daemonize(): void {
        // If not already running as the daemon child, spawn a detached child and exit parent
        if (process.env.ORCBOT_DAEMON_CHILD !== '1') {
            const { spawn } = require('child_process');
            const nodePath = process.execPath;
            const scriptPath = process.argv[1];

            const child = spawn(
                nodePath,
                [scriptPath, 'run', '--daemon', '--daemon-child'],
                {
                    detached: true,
                    stdio: 'ignore',
                    env: { ...process.env, ORCBOT_DAEMON_CHILD: '1' }
                }
            );

            child.unref();
            console.log('\n✅ OrcBot daemon spawn requested.');
            console.log(`   PID file: ${this.pidFile}`);
            console.log(`   Log file: ${this.logFile}`);
            console.log('   Use "orcbot daemon status" to verify it is running.');
            process.exit(0);
        }

        // Ensure data directory exists
        if (!fs.existsSync(this.dataDir)) {
            fs.mkdirSync(this.dataDir, { recursive: true });
        }

        // Check if already running
        const status = this.isRunning();
        if (status.running) {
            console.error(`\n❌ Cannot start daemon: OrcBot daemon is already running`);
            console.error(`   Daemon PID: ${status.pid}`);
            console.error(`   PID file: ${this.pidFile}`);
            console.error('\n   To stop the daemon first, run:');
            console.error(`   $ orcbot daemon stop`);
            console.error('\n   Or to view daemon status:');
            console.error(`   $ orcbot daemon status`);
            console.error('');
            process.exit(1);
        }

        // Display daemon startup info before detaching
        console.log('\n✅ Starting OrcBot in daemon mode...');
        console.log(`   PID file: ${this.pidFile}`);
        console.log(`   Log file: ${this.logFile}`);
        console.log(`   Data dir: ${this.dataDir}`);
        console.log('\n   To view logs: tail -f ' + this.logFile);
        console.log('   To stop: kill $(cat ' + this.pidFile + ')');
        console.log('');

        // Write PID file before forking (in case parent exits quickly)
        this.writePidFile(process.pid);

        // Setup cleanup on exit
        let cleaned = false;
        let exitReason = 'unknown';
        const cleanup = (reason?: string) => {
            if (cleaned) return;
            cleaned = true;
            if (reason) exitReason = reason;
            logger.warn(`Daemon cleanup triggered: ${exitReason}`);
            this.removePidFile(exitReason);
        };

        process.on('beforeExit', (code) => {
            cleanup(`beforeExit:${code}`);
        });

        process.on('exit', (code) => {
            cleanup(`exit:${code}`);
        });

        process.on('SIGINT', () => {
            cleanup('SIGINT');
            process.exit(0);
        });

        process.on('SIGTERM', () => {
            cleanup('SIGTERM');
            process.exit(0);
        });

        process.on('SIGQUIT', () => {
            cleanup('SIGQUIT');
            process.exit(0);
        });

        process.on('SIGABRT', () => {
            cleanup('SIGABRT');
            process.exit(0);
        });

        // Setup daemon logging
        this.setupDaemonLogging();

        // Detach from terminal by ignoring SIGHUP
        // This allows the process to continue running after terminal closes
        process.on('SIGHUP', () => {
            logger.info('Received SIGHUP, continuing in background...');
        });

        // Unref stdin/stdout/stderr so Node doesn't wait for them
        if (process.stdin && typeof (process.stdin as any).unref === 'function') {
            (process.stdin as any).unref();
        }
        if (process.stdout && typeof (process.stdout as any).unref === 'function') {
            (process.stdout as any).unref();
        }
        if (process.stderr && typeof (process.stderr as any).unref === 'function') {
            (process.stderr as any).unref();
        }

        logger.info('OrcBot daemon started successfully');
    }

    /**
     * Get daemon status
     */
    public getStatus(): string {
        const status = this.isRunning();
        if (status.running) {
            return `OrcBot daemon is running (PID: ${status.pid})\nPID file: ${this.pidFile}\nLog file: ${this.logFile}`;
        } else {
            return 'OrcBot daemon is not running';
        }
    }

    /**
     * Create a default DaemonManager instance with standard paths
     */
    public static createDefault(): DaemonManager {
        const dataDir = path.join(os.homedir(), '.orcbot');
        const pidFile = path.join(dataDir, 'orcbot.pid');
        const logFile = path.join(dataDir, 'daemon.log');

        return new DaemonManager({ pidFile, logFile, dataDir });
    }
}
